#!/usr/bin/env python3
"""WorldPop official polygon-only download and QA. Python 3.10+.
pip install requests numpy rasterio shapely pyproj
python download_worldpop.py [--boundary PATH] [--out DIR] [--overwrite]
Optional WORLDPOP_API_KEY: environment variable, never logged.
Only six summed GeoTIFFs are saved. No national raster, resampling or filling.
"""
import argparse, csv, hashlib, json, os, time
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
import numpy as np
import requests
import rasterio
from rasterio.features import geometry_mask
from shapely.geometry import shape
from shapely.ops import unary_union
from pyproj import Geod

BASE='https://api.worldpop.org/v3'
SPECS=[('Total','population',None,None),('65plus','agesex',[65,90],'both'),
       ('0_14','agesex',[0,14],'both'),('15_64','agesex',[15,64],'both'),
       ('Male','agesex',[0,90],'male'),('Female','agesex',[0,90],'female')]

def dump(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def delay(response, attempt):
    raw=response.headers.get('Retry-After') if response is not None else None
    try: return max(0,float(raw)) if raw else min(60,2**attempt)
    except ValueError:
        return max(0,(parsedate_to_datetime(raw)-datetime.now(timezone.utc)).total_seconds())

def request(session,method,url,log,**kwargs):
    for attempt in range(6):
        r=None
        try:
            r=session.request(method,url,timeout=(30,240),**kwargs)
            entry={'utc':datetime.now(timezone.utc).isoformat(),'method':method,'url':url,
                   'status':r.status_code,'headers':dict(r.headers),'attempt':attempt+1}
            if not r.ok:entry['error_body']=r.text[:8000]
            with log.open('a',encoding='utf-8') as f:f.write(json.dumps(entry,ensure_ascii=False)+'\n')
            if r.status_code==429 or r.status_code in (500,502,503,504):
                wait=delay(r,attempt)
                r.close()
                if wait>300:raise RuntimeError(f'服务器要求等待 {wait}s；停止以遵守限流，请稍后重跑')
                if attempt==5:r.raise_for_status()
                print(f'HTTP {r.status_code}; retry in {wait}s',flush=True)
                time.sleep(wait);continue
            r.raise_for_status();return r
        except (requests.ConnectionError,requests.Timeout) as exc:
            if r is not None:r.close()
            if attempt==5:raise
            with log.open('a',encoding='utf-8') as f:f.write(json.dumps({'error':str(exc),'attempt':attempt+1})+'\n')
            time.sleep(min(60,2**attempt))
    raise RuntimeError('请求失败')

def inspect(path):
    with rasterio.open(path) as d:
        a=d.read(1,masked=True);v=a.compressed()
        if d.driver!='GTiff' or d.count!=1:raise ValueError('Not single-band GeoTIFF')
        if d.crs!=rasterio.crs.CRS.from_epsg(4326):raise ValueError('Unexpected CRS')
        if v.size==0 or not np.isfinite(v).all() or (v<0).any():raise ValueError('Empty, nonfinite or negative population')
        return {'文件':path.name,'状态':'成功','字节':path.stat().st_size,'SHA256':hashlib.sha256(path.read_bytes()).hexdigest(),
                '宽':d.width,'高':d.height,'总像元数':d.width*d.height,'有效像元数':int(v.size),
                'NoData像元数':int(a.mask.sum()) if np.ndim(a.mask) else 0,'人口总量':float(v.sum(dtype=np.float64)),
                '最小人口':float(v.min()),'最大人口':float(v.max()),'波段数':d.count,'数据类型':d.dtypes[0],
                'CRS':str(d.crs),'分辨率X度':d.res[0],'分辨率Y度':d.res[1],'范围':list(d.bounds),
                'NoData值':d.nodata,'仿射变换':list(d.transform),'波段描述':list(d.descriptions),
                'GDAL可读取':'是；未进行QGIS图形界面实测'},a

def main():
    p=argparse.ArgumentParser(description=__doc__)
    root=Path(__file__).resolve().parent
    p.add_argument('--boundary',type=Path,default=root/'天津市津城核心区_WGS84边界.geojson')
    p.add_argument('--out',type=Path,default=root);p.add_argument('--overwrite',action='store_true');args=p.parse_args()
    out=args.out;out.mkdir(parents=True,exist_ok=True);log=out/'HTTP请求日志.jsonl'
    raw=json.loads(args.boundary.read_text(encoding='utf-8-sig'))
    if raw.get('crs') and '4326' not in json.dumps(raw['crs']) and 'CRS84' not in json.dumps(raw['crs']):raise ValueError('Boundary CRS is not EPSG:4326')
    if raw['type']=='FeatureCollection':g=unary_union([shape(f['geometry']) for f in raw['features']])
    else:g=shape(raw['geometry'] if raw['type']=='Feature' else raw)
    if not g.is_valid or g.is_empty or g.geom_type not in ('Polygon','MultiPolygon'):raise ValueError('Invalid polygon; not auto-repaired')
    w,s,e,n=g.bounds
    if not(116.5<w<e<118.5 and 38.5<s<n<40):raise ValueError('Outside expected Tianjin extent')
    geom=json.loads(json.dumps(g.__geo_interface__))
    session=requests.Session();session.headers['User-Agent']='WorldPop-Tianjin-Research/1.0'
    if os.environ.get('WORLDPOP_API_KEY'):session.headers['X-API-Key']=os.environ['WORLDPOP_API_KEY']
    for endpoint in ['health','catalog','openapi.json']:
        r=request(session,'GET',BASE+'/'+endpoint,log);dump(out/(endpoint.replace('.json','')+'_官方.json'),r.json());r.close()
    dump(out/'运行参数.json',{'utc':datetime.now(timezone.utc).isoformat(),'boundary_sha256':hashlib.sha256(args.boundary.read_bytes()).hexdigest(),'area_km2':abs(Geod(ellps='WGS84').geometry_area_perimeter(g)[0])/1e6,'year':2025,'grid':'100m','specs':SPECS})
    rows=[];arrays={};checks={};errors=[]
    for key,layer,ages,sex in SPECS:
        name=f'Jincheng_Pop_{key}_2025.tif';path=out/name
        body={'geojson':geom,'year':2025,'resolution':'100m','layer':layer}
        if layer=='agesex':body.update(age_range=ages,sex=sex,bands='sum')
        dump(out/(name+'.request.json'),body)
        try:
            if not path.exists() or args.overwrite:
                # Polygon POST has no documented byte-range resume: discard incomplete
                # .part and repeat the whole clipped request, never append responses.
                for attempt in range(4):
                    part=path.with_suffix('.tif.part')
                    try:
                        r=request(session,'POST',BASE+'/raster',log,json=body,stream=True)
                        dump(out/(name+'.headers.json'),dict(r.headers))
                        length=r.headers.get('Content-Length')
                        with part.open('wb') as f:
                            for chunk in r.iter_content(1024*1024):f.write(chunk)
                        r.close()
                        if length and part.stat().st_size!=int(length):raise requests.ConnectionError('Truncated response')
                        with part.open('rb') as f:magic=f.read(4)
                        if magic not in (b'II*\x00',b'MM\x00*',b'II+\x00',b'MM\x00+'):
                            raise ValueError('Response is not a TIFF: '+part.read_bytes()[:500].decode(errors='replace'))
                        inspect(part);part.replace(path);break
                    except (requests.RequestException,OSError) as exc:
                        part.unlink(missing_ok=True)
                        if attempt==3:raise
                        print('Download interrupted:',exc,flush=True);time.sleep(2**attempt)
            row,arr=inspect(path)
            with rasterio.open(path) as d:
                inside=geometry_mask([geom],(d.height,d.width),d.transform,invert=True,all_touched=False)
                valid=d.read_masks(1)>0
                if np.any(valid & ~inside):raise ValueError('Valid cells outside boundary')
                row['无区外有效像元核验']='通过'
                row['边界内中心点像元数']=int(inside.sum())
                row['边界内NoData像元数']=int(np.sum(inside & ~valid))
            rows.append(row);arrays[key]=arr
            print(key,json.dumps(row,ensure_ascii=False),flush=True)
        except Exception as exc:
            errors.append({'file':name,'error':str(exc)});rows.append({'文件':name,'状态':'失败','错误':str(exc)})
            print('FAILED',key,str(exc),flush=True)
            if key in ('Total','65plus'):
                errors.append({'error':'优先测试未通过，停止其余下载'});break
    if 'Total' in arrays:
        ref=next(r for r in rows if r['文件']=='Jincheng_Pop_Total_2025.tif')
        for row in rows:
            if row['状态']=='成功':row['网格对齐']=all(row[k]==ref[k] for k in ['CRS','宽','高','仿射变换'])
        aligned=all(r.get('网格对齐',False) for r in rows)
        checks['all_grids_aligned']=aligned
        checks['same_valid_mask']=all(np.array_equal(np.ma.getmaskarray(a),np.ma.getmaskarray(arrays['Total'])) for a in arrays.values()) if aligned else False
        for label,keys in [('男性加女性',['Male','Female']),('三个年龄组',['0_14','15_64','65plus'])]:
            if aligned and all(k in arrays for k in keys):
                aa=[arrays['Total']]+[arrays[k] for k in keys]
                mask=np.logical_or.reduce([np.ma.getmaskarray(a) for a in aa]);valid=~mask
                total=aa[0].data[valid].astype(np.float64);parts=sum(a.data[valid].astype(np.float64) for a in aa[1:]);diff=parts-total
                denom=float(total.sum());checks[label]={'共同有效像元数':int(valid.sum()),'总人口':denom,'分组之和':float(parts.sum()),'差值人':float(diff.sum()),'相对误差':float(abs(diff.sum())/denom),'相对误差百分比':float(abs(diff.sum())/denom*100),'像元绝对差最大值':float(abs(diff).max()),'像元绝对差均值':float(abs(diff).mean()),'通过':bool(np.allclose(parts,total,rtol=1e-5,atol=0.001))}
    # Verify 65+ includes the open-ended band using /agesex metadata, not a
    # seventh TIFF. Save exact official returned age classes and population.
    if '65plus' in arrays:
        try:
            body={'geojson':geom,'year':2025,'age_range':[65,90],'sex':'both'}
            r=request(session,'POST',BASE+'/agesex',log,json=body);meta=r.json();r.close();dump(out/'65plus_官方年龄组核验.json',meta)
            checks['65plus_age_metadata']=meta
            bands=meta.get('bands',{})
            chosen=[f'{sex}_{age:02d}' for sex in ('f','m') for age in (65,70,75,80,85,90)]
            group_sum=sum(bands[k] for k in chosen)
            checks['90plus_verification']={'returned_age_range':meta.get('age_range'),
                'f_90':bands.get('f_90'),'m_90':bands.get('m_90'),
                '90plus_total':bands['f_90']+bands['m_90'],
                'six_age_classes_both_sexes_sum':group_sum,
                'api_65plus_total':meta['total_population'],
                'passed':meta.get('age_range')==[65,90] and abs(group_sum-meta['total_population'])<0.1}
            if not checks['90plus_verification']['passed']:raise ValueError('90+ inclusion check failed')
        except Exception as exc:errors.append({'error':'65+元数据核验失败: '+str(exc)})
    for row in rows:
        if row['状态']=='成功':
            row['有效掩膜一致']=checks.get('same_valid_mask')
            row['65plus包含90plus核验']=checks.get('90plus_verification',{}).get('passed','未完成')
            for label in ['男性加女性','三个年龄组']:
                row[label+'相对误差']=checks.get(label,{}).get('相对误差','未完成');row[label+'一致性通过']=checks.get(label,{}).get('通过','未完成')
    columns=list(dict.fromkeys(k for row in rows for k in row))
    with (out/'人口数据检查报告.csv').open('w',encoding='utf-8-sig',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=columns);wr.writeheader();wr.writerows(rows)
    dump(out/'一致性检查.json',checks);dump(out/'下载错误记录.json',errors)
    dump(out/'栅格元数据.json',rows)
    print('CHECKS',json.dumps(checks,ensure_ascii=False),flush=True)
    if errors:raise SystemExit(1)

if __name__=='__main__':main()
